import { useState } from "react";
import { Plus, Search, Filter, Download, Package } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import PageHeader from "@/components/common/PageHeader";
import DataTable, { Column } from "@/components/common/DataTable";
import { Link } from "react-router-dom";

interface Product {
  id: string;
  code: string;
  name: string;
  category: string;
  origin: string;
  stock: number;
  minStock: number;
  unit: string;
  status: "active" | "inactive";
}

// Mock data
const mockProducts: Product[] = [
  { id: "1", code: "VT-2024-0001", name: "Bóng đèn LED 40W", category: "Thiết bị điện", origin: "Việt Nam", stock: 150, minStock: 20, unit: "cái", status: "active" },
  { id: "2", code: "VT-2024-0002", name: "Dây điện 2.5mm", category: "Vật tư điện", origin: "Việt Nam", stock: 12, minStock: 50, unit: "cuộn", status: "active" },
  { id: "3", code: "EQ-2024-0001", name: "Máy khoan cầm tay Bosch", category: "Thiết bị cơ khí", origin: "Đức", stock: 8, minStock: 5, unit: "chiếc", status: "active" },
  { id: "4", code: "VT-2024-0003", name: "Ốc vít M8", category: "Vật tư cơ khí", origin: "Trung Quốc", stock: 500, minStock: 100, unit: "cái", status: "active" },
  { id: "5", code: "EQ-2024-0002", name: "Máy hàn điện tử", category: "Thiết bị cơ khí", origin: "Nhật Bản", stock: 3, minStock: 2, unit: "chiếc", status: "active" },
];

const Products = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("all");

  const columns: Column<Product>[] = [
    {
      key: "code",
      header: "Mã hàng",
      render: (item) => (
        <span className="font-mono text-sm font-medium">{item.code}</span>
      ),
    },
    {
      key: "name",
      header: "Tên hàng hóa",
      render: (item) => (
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-muted rounded-lg flex items-center justify-center">
            <Package className="w-5 h-5 text-muted-foreground" />
          </div>
          <span className="font-medium">{item.name}</span>
        </div>
      ),
    },
    {
      key: "category",
      header: "Loại hàng",
      render: (item) => (
        <Badge variant="secondary">{item.category}</Badge>
      ),
    },
    {
      key: "origin",
      header: "Xuất xứ",
    },
    {
      key: "stock",
      header: "Tồn kho",
      render: (item) => {
        const isLow = item.stock <= item.minStock;
        return (
          <div className="flex items-center gap-2">
            <span className={isLow ? "text-destructive font-semibold" : "font-medium"}>
              {item.stock}
            </span>
            <span className="text-muted-foreground text-sm">{item.unit}</span>
            {isLow && (
              <Badge variant="destructive" className="text-xs">Thấp</Badge>
            )}
          </div>
        );
      },
    },
    {
      key: "status",
      header: "Trạng thái",
      render: (item) => (
        <Badge variant={item.status === "active" ? "default" : "secondary"}>
          {item.status === "active" ? "Hoạt động" : "Ngừng"}
        </Badge>
      ),
    },
    {
      key: "actions",
      header: "",
      render: (item) => (
        <div className="flex items-center gap-2">
          <Button variant="ghost" size="sm" asChild>
            <Link to={`/admin/products/${item.id}`}>Chi tiết</Link>
          </Button>
          <Button variant="ghost" size="sm" asChild>
            <Link to={`/admin/products/${item.id}/edit`}>Sửa</Link>
          </Button>
        </div>
      ),
      className: "text-right",
    },
  ];

  const filteredProducts = mockProducts.filter((p) => {
    const matchSearch = p.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.code.toLowerCase().includes(searchTerm.toLowerCase());
    const matchCategory = categoryFilter === "all" || p.category === categoryFilter;
    return matchSearch && matchCategory;
  });

  return (
    <div className="animate-fade-in">
      <PageHeader
        title="Quản lý hàng hóa"
        description="Danh sách tất cả hàng hóa, thiết bị, vật tư trong kho"
        breadcrumbs={[
          { label: "Trang chủ", href: "/admin" },
          { label: "Hàng hóa" },
        ]}
        actions={
          <>
            <Button variant="outline">
              <Download className="w-4 h-4 mr-2" />
              Xuất Excel
            </Button>
            <Button asChild>
              <Link to="/admin/products/create">
                <Plus className="w-4 h-4 mr-2" />
                Thêm mới
              </Link>
            </Button>
          </>
        }
      />

      {/* Filters */}
      <div className="bg-card rounded-xl border p-4 mb-6 flex flex-col sm:flex-row gap-4">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Tìm theo tên hoặc mã hàng..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>
        <Select value={categoryFilter} onValueChange={setCategoryFilter}>
          <SelectTrigger className="w-full sm:w-48">
            <Filter className="w-4 h-4 mr-2" />
            <SelectValue placeholder="Loại hàng" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Tất cả loại</SelectItem>
            <SelectItem value="Thiết bị điện">Thiết bị điện</SelectItem>
            <SelectItem value="Vật tư điện">Vật tư điện</SelectItem>
            <SelectItem value="Thiết bị cơ khí">Thiết bị cơ khí</SelectItem>
            <SelectItem value="Vật tư cơ khí">Vật tư cơ khí</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Table */}
      <DataTable
        columns={columns}
        data={filteredProducts}
        keyExtractor={(item) => item.id}
        emptyMessage="Không tìm thấy hàng hóa nào"
        pagination={{
          currentPage: 1,
          totalPages: 5,
          onPageChange: (page) => console.log("Page:", page),
        }}
      />
    </div>
  );
};

export default Products;
